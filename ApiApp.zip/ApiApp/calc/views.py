from django.shortcuts import render
from rest_framework.renderers import JSONRenderer
import urllib
from calc.models import data_feed

def index(request):
    # defining endpoint variable
    url = "https://api.eot.pt/api/meter/feed.json?key=W7JMJZUHO4J88IWJ&results=5"
    data = urllib.urlopen(url).read()
    content = JSONRenderer().render(data)
    return render(request, 'clac/index.html', content)

def data_save(request):
    titles = data_feed.objects.all()
    context = {'titles': titles}
    return render(request, 'clac/index.html', context)

