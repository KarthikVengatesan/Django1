from django.db import models


# Create your models here.
class data_feed(models.Model):
    g_id = models.IntegerField()
    g_feeds = models.IntegerField()


def __str__(self):
    return self.g_id
